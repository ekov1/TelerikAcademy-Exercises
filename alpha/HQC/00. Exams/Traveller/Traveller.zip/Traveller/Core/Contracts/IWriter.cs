﻿namespace Traveller.Core.Contracts
{
    public interface IWriter
    {
        void Write(string message);
    }
}
