﻿namespace Traveller.Commands.Creating
{
    // TODO
    class ListVehiclesCommand
    {
        
    }
}
