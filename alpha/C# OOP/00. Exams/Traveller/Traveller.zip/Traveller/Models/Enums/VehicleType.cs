﻿namespace Traveller.Models.Enums
{
    public enum VehicleType
    {
        Land,
        Air,
        Sea
    }
}
